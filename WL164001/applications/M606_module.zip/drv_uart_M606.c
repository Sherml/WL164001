/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-11-16     liwentai       the first version
 */
#include "M606.h"

static struct rt_M606_config M606_config[]=
{
        M606_config_0,
        M606_config_1,
};

static rt_err_t M606_rx(rt_device_t dev, rt_size_t size)
{
    M606_device_t M606 = (M606_device_t)(dev->user_data);

    struct rx_msg msg;
    rt_err_t result;
    msg.dev = dev;
    msg.size = size;

    LOG_D("RX: %d\n",size);
    result = rt_mq_send(&rx_mq, &msg, sizeof(msg));
    if ( result == -RT_EFULL){
        rt_kprintf("message queue full！\n");
    }
    return result;
}

M606_device_t M606_init(const char* uart_name)
{
    M606_device_t dev;
    struct serial_configure config = RFID_SERIAL_CONFIG;
    static char msg_pool[4000];

    RT_ASSERT(uart_name);

    dev = rt_calloc(1, sizeof(struct M606_device));
    if (dev == RT_NULL) {
        LOG_E("Can't allocate memory for M606 device on '%s' ", uart_name);
        rt_free(dev);
    }

    dev->serial = rt_device_find(uart_name);
    rt_device_control(dev->serial, RT_DEVICE_CTRL_CONFIG, &config);


    rt_mq_init(&dev->rx_mq,
                "rx_mq",
                msg_pool,
                sizeof(struct rx_msg),
                sizeof(msg_pool),
                RT_IPC_FLAG_FIFO);

    return dev;
}

rt_err_t rt_device_M606_register(M606_device_t dev, const char* M606_name)
{
    rt_device_t device = RT_NULL;
    device = rt_calloc(1, sizeof(struct rt_device));
    if (device == RT_NULL)
    {
        LOG_E("can't allocate memory for M606 device");
        free(device);
    }

    /* register device */
    device->type = RT_Device_Class_Miscellaneous;
    device->user_data = (void*) dev;

    return rt_device_register(device, M606_name, RT_DEVICE_FLAG_STANDALONE);
}

static int rt_hw_M606_port(void)
{
    for (int i = 0; i < ITEM_NUM(M606_config); i++)
    {
        M606_config[i].dev = M606_init(M606_config[i].uart_name);
        if (rt_device_M606_register(M606_config[i].dev, M606_config[i].name) != RT_EOK)
        {
            LOG_E("M606 device %s register failed.", M606_config[i].name);
            return -RT_ERROR;
        }else {
            rt_device_find(name);
                rt_device_set_rx_indicate(M606_config[i].dev->serial, uart_input);
        }

    }

    return RT_EOK;
}
