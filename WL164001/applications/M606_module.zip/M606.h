/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-10-28     liwentai       the first version
 */
#ifndef APPLICATIONS_RFID_MODULE_DRV_M606_H_
#define APPLICATIONS_RFID_MODULE_DRV_M606_H_

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <stdio.h>
#include <tool.h>


#define RFID_UART3_NAME "uart2"
#define RFID_NUM  6

#define RFID_SERIAL_CONFIG  \
{                           \
    BAUD_RATE_38400,        \
    DATA_BITS_8,            \
    STOP_BITS_1,            \
    PARITY_NONE,            \
    BIT_ORDER_LSB,          \
    NRZ_NORMAL,             \
    128,                   \
    0                       \
}

#define M606_config_0           \
    {                           \
        .uart_name = "uart3",   \
        .pos       = 0          \
    }

#define M606_config_1           \
    {                           \
        .uart_name = "uart2",   \
        .pos       = 6          \
    }

struct M606_device
{
    rt_serial_t serial;
    struct rt_messagequeue rx_mq;
    rt_off_t pos;
};
typedef struct M606_device* M606_device_t;

struct rt_M606_config
{
    M606_device_t dev;
    const char* uart_name;
    rt_off_t pos;
};

struct rx_msg
{
    rt_device_t dev;
    rt_size_t size;
};
struct rt_messagequeue rx_mq;

rt_device_t M606_init(const char *uart_name);
rt_err_t scan_rfid(char* src_code);
char *rfid_get();
int rfid_printf(int i);
int M606_open();

#endif /* APPLICATIONS_RFID_MODULE_DRV_M606_H_ */
